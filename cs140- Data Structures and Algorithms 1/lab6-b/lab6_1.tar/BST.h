#ifndef BST_H
#define BST_H

#include <iomanip>
#include <iostream>
#include <queue>
#include <vector>
#include <string>
using namespace std;

int y = 0;

template <class TKey>
class bst {
	struct node {
		//node(ID);
		//node();

		void print();


		TKey key;
		//ID parameter

		//parent info
		node *left;
		node *right;
		node *parent = NULL;
		int id;
	};

	//  public:
	//  class iterator {
	//  public:
	//  default constructor (no argument)
	//overloaded operators (++, *, ==, !=)
	//private:
	//friend class bst<TKey>;
	//constructor (with argument)

	//node *p;
	//};

	//iterator begin() { ... }
	//iterator end() { ... }

	public:
	bst() { Troot=NULL; }
	~bst() { clear(Troot); }

	bool empty() { return Troot==NULL; }

	void insert(TKey &);

	//iterator lower_bound(const TKey &);
	//iterator upper_bound(const TKey &);

	void print_bylevel();

	private:
	void clear(node *);
	node *insert(node *, TKey &);

	//ID parameter
	node *Troot;
};

//wasnt able to iterate ids through the constructor so they are commented out
//template <>
//bst<Tkey>::node::node(){

//	id = 0;
//	parent = NULL;
//}

//template <>
//bst<Tkey>::node::node(ID){

//	id = ID;
//	parent = NULL;
//}

//added a print for the id and check for parent node
template <class TKey>
void bst<TKey>::node::print()
{
	cout << setw(3) << id << ' ';
	cout << setw(3) << key << " : ";

	//output node and parent ID information

	if(parent == NULL){

		cout << "ROOT ";
	}else{

		cout << "P=  " << parent->id;
	}
	//change below to output subtree ID information


	if (left)  cout << " L=" << setw(3) << left->id;
	else       cout << "      ";
	if (right) cout << " R=" << setw(3) << right->id;
	else       cout << "      ";

	cout << "\n";
}

//specialized string version of the above goes here


template <>
void bst<string>::node::print()
{
	cout << setw(3) << id << ' ';
	cout << setw(20) << key << " : ";

	//output node and parent ID information

	if(parent == NULL){

		cout << "ROOT ";
	}else{

		cout << "P=  " << parent->id;
	}
	//change below to output subtree ID information


	if (left)  cout << " L=" << setw(3) << left->id;
	else       cout << "      ";
	if (right) cout << " R=" << setw(3) << right->id;
	else       cout << "      ";

	cout << "\n";
}

//bst<TKey>::iterator functions not defined above go here

template <class TKey>
void bst<TKey>::clear(node *T)
{
	if (T) {
		clear(T->left);
		clear(T->right);
		delete T;
		T = NULL;
	}
}

template <class TKey>
void bst<TKey>::insert(TKey &key)
{
	Troot = insert(Troot, key);
}

//added check for id iteration as well as updating the parent nodes for each new node
template <class TKey>
class bst<TKey>::node *bst<TKey>::insert(node *T, TKey &key)
{
	//set parent link below
		if (T == NULL) {
			//update and set node ID
				y++;
				T = new node;
				T->id = y;
			T->key = key;
		} else if (T->key == key) {
			;
		} else if (key < T->key) {
			T->left = insert(T->left, key);
			T->left->parent = T;
		} else {
			T->right = insert(T->right, key);
			T->right->parent = T;
		}

	return T;
}

//bst<TKey>::lower_bound function goes here

//bst<TKey>::upper_bound function goes here

template <class TKey>
void bst<TKey>::print_bylevel()
{
	if (Troot == NULL)
		return;

	queue<node *> Q;
	node *T;

	Q.push(Troot);
	while (!Q.empty()) {
		T = Q.front();
		Q.pop();

		T->print();
		if (T->left)  Q.push(T->left);
		if (T->right) Q.push(T->right);
	}
}
#endif
